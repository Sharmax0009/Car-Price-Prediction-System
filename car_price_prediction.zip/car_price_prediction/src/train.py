"""Train, compare and save the best car price model."""
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer, TransformedTargetRegressor
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from config import CATEGORICAL, DATA_PATH, METRICS_PATH, MODEL_PATH, NUMERIC, TARGET


def build_pipeline(estimator):
    pre = ColumnTransformer([
        ("num", StandardScaler(), NUMERIC),
        ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL),
    ])
    # Predict log(price): prices are skewed and errors are proportional.
    model = TransformedTargetRegressor(estimator, func=np.log1p, inverse_func=np.expm1)
    return Pipeline([("pre", pre), ("model", model)])


def evaluate(pipe, X, y):
    pred = pipe.predict(X)
    return {
        "MAE": float(mean_absolute_error(y, pred)),
        "RMSE": float(np.sqrt(mean_squared_error(y, pred))),
        "R2": float(r2_score(y, pred)),
        "MAPE_%": float(np.mean(np.abs((y - pred) / y)) * 100),
    }


def main(quick=False):
    if not DATA_PATH.exists():
        from generate_data import generate
        DATA_PATH.parent.mkdir(exist_ok=True)
        generate().to_csv(DATA_PATH, index=False)

    df = pd.read_csv(DATA_PATH).dropna()
    df = df[df[TARGET] > 0]
    X, y = df[NUMERIC + CATEGORICAL], df[TARGET]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)

    candidates = {
        "Ridge": (Ridge(), {"model__regressor__alpha": [0.1, 1, 10]}),
        "RandomForest": (RandomForestRegressor(random_state=42, n_jobs=-1),
                         {"model__regressor__n_estimators": [200],
                          "model__regressor__min_samples_leaf": [1, 3]}),
        "GradientBoosting": (GradientBoostingRegressor(random_state=42),
                             {"model__regressor__n_estimators": [300],
                              "model__regressor__learning_rate": [0.05, 0.1],
                              "model__regressor__max_depth": [3, 4]}),
    }

    if quick:  # fast fallback used on first launch in the cloud
        candidates = {"GradientBoosting": (GradientBoostingRegressor(random_state=42),
                      {"model__regressor__n_estimators": [300],
                       "model__regressor__learning_rate": [0.1],
                       "model__regressor__max_depth": [3]})}

    results, best_name, best_model, best_rmse = {}, None, None, float("inf")
    for name, (est, grid) in candidates.items():
        search = GridSearchCV(build_pipeline(est), grid, cv=2 if quick else 3,
                              scoring="neg_root_mean_squared_error", n_jobs=-1)
        search.fit(X_tr, y_tr)
        m = evaluate(search.best_estimator_, X_te, y_te)
        results[name] = m
        print(f"{name:<18} MAE={m['MAE']:>9,.0f}  RMSE={m['RMSE']:>9,.0f}  "
              f"R2={m['R2']:.4f}  MAPE={m['MAPE_%']:.1f}%")
        if m["RMSE"] < best_rmse:
            best_name, best_model, best_rmse = name, search.best_estimator_, m["RMSE"]

    MODEL_PATH.parent.mkdir(exist_ok=True)
    joblib.dump(best_model, MODEL_PATH)
    METRICS_PATH.write_text(json.dumps({"best_model": best_name, "results": results}, indent=2))
    print(f"\nBest model: {best_name} -> saved to {MODEL_PATH}")


if __name__ == "__main__":
    main()

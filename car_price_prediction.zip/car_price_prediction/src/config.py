from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = ROOT / "data" / "cars.csv"
MODEL_PATH = ROOT / "models" / "car_price_model.joblib"
METRICS_PATH = ROOT / "models" / "metrics.json"

CURRENCY = "$"
CURRENT_YEAR = 2026

TARGET = "price"
CATEGORICAL = ["brand", "fuel_type", "transmission", "owner_type"]
NUMERIC = ["age", "km_driven", "engine_cc", "power_hp", "mileage_kmpl", "seats"]

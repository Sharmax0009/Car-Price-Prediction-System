"""Load the trained model and predict a price. Usable as a module or a CLI."""
import argparse
import joblib
import pandas as pd
from config import CATEGORICAL, CURRENCY, CURRENT_YEAR, MODEL_PATH, NUMERIC

_model = None


def load_model():
    global _model
    if _model is None:
        try:
            _model = joblib.load(MODEL_PATH)
        except Exception:
            # Missing file, or saved with an incompatible scikit-learn version:
            # retrain quickly and load the fresh model.
            from train import main as train_main
            train_main(quick=True)
            _model = joblib.load(MODEL_PATH)
    return _model


def predict_price(car: dict, margin: float = 0.08) -> dict:
    """Return the estimated price and a rough +/- range (margin as a fraction)."""
    row = dict(car)
    if "age" not in row and "year" in row:
        row["age"] = CURRENT_YEAR - int(row.pop("year"))
    df = pd.DataFrame([row])[NUMERIC + CATEGORICAL]
    price = float(load_model().predict(df)[0])
    return {"price": round(price, -1), "low": round(price * (1 - margin), -1),
            "high": round(price * (1 + margin), -1)}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Predict a used car price")
    p.add_argument("--brand", default="Honda")
    p.add_argument("--fuel_type", default="Petrol")
    p.add_argument("--transmission", default="Manual")
    p.add_argument("--owner_type", default="First")
    p.add_argument("--age", type=int, default=5)
    p.add_argument("--km_driven", type=int, default=50000)
    p.add_argument("--engine_cc", type=int, default=1500)
    p.add_argument("--power_hp", type=float, default=110)
    p.add_argument("--mileage_kmpl", type=float, default=18)
    p.add_argument("--seats", type=int, default=5)
    r = predict_price(vars(p.parse_args()))
    print(f"Estimated price: {CURRENCY}{r['price']:,.0f}  (range {CURRENCY}{r['low']:,.0f} - {CURRENCY}{r['high']:,.0f})")

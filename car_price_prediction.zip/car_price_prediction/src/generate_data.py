"""Generate a realistic synthetic used-car dataset (used when you have no real CSV).

To use real data (e.g. a Kaggle used-car dataset), put it at data/cars.csv with the
columns: brand, fuel_type, transmission, owner_type, age, km_driven, engine_cc,
power_hp, mileage_kmpl, seats, price.
"""
import numpy as np
import pandas as pd
from config import DATA_PATH

BRANDS = {  # brand: (base new price, depreciation speed)
    "Maruti": (11000, 0.13), "Hyundai": (14000, 0.13), "Honda": (19000, 0.12),
    "Toyota": (24000, 0.10), "Ford": (17000, 0.15), "Volkswagen": (20000, 0.14),
    "BMW": (52000, 0.15), "Mercedes": (58000, 0.15), "Audi": (50000, 0.16),
}


def generate(n=6000, seed=42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    brand = rng.choice(list(BRANDS), n)
    fuel = rng.choice(["Petrol", "Diesel", "CNG", "Electric"], n, p=[.50, .38, .07, .05])
    trans = rng.choice(["Manual", "Automatic"], n, p=[.62, .38])
    owner = rng.choice(["First", "Second", "Third"], n, p=[.70, .22, .08])
    age = rng.integers(0, 16, n)
    km = np.clip(rng.normal(age * 11000 + 3000, 6000), 500, None).astype(int)
    engine = np.where(fuel == "Electric", 0, rng.choice([800, 1000, 1200, 1500, 1800, 2000, 2500, 3000], n))
    power = np.where(fuel == "Electric", rng.integers(90, 300, n), engine * 0.07 + rng.normal(15, 8, n)).round(1)
    power = np.clip(power, 35, None)
    mileage = np.where(fuel == "Electric", 0, np.clip(30 - engine / 150 + rng.normal(0, 2, n), 8, 28)).round(1)
    seats = rng.choice([2, 4, 5, 7], n, p=[.02, .08, .72, .18])

    base = np.array([BRANDS[b][0] for b in brand], dtype=float)
    dep = np.array([BRANDS[b][1] for b in brand])
    price = base * (1 + power / 400) * np.exp(-dep * age)
    price *= np.exp(-km / 400000)
    price *= np.where(trans == "Automatic", 1.12, 1.0)
    price *= np.select([fuel == "Diesel", fuel == "Electric", fuel == "CNG"], [1.06, 1.15, 0.94], 1.0)
    price *= np.select([owner == "Second", owner == "Third"], [0.92, 0.84], 1.0)
    price *= np.exp(rng.normal(0, 0.06, n))  # market noise
    price = price.round(-1)

    return pd.DataFrame(dict(brand=brand, fuel_type=fuel, transmission=trans, owner_type=owner,
                             age=age, km_driven=km, engine_cc=engine, power_hp=power,
                             mileage_kmpl=mileage, seats=seats, price=price))


if __name__ == "__main__":
    df = generate()
    DATA_PATH.parent.mkdir(exist_ok=True)
    df.to_csv(DATA_PATH, index=False)
    print(f"Saved {len(df)} rows to {DATA_PATH}")
